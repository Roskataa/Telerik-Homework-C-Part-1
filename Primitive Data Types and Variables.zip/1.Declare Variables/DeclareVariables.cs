﻿using System;

class DeclareVariables
{
    static void Main()
    {
        byte apples = 97;
        sbyte pearhes = -115;
        short pears = -10000;
        ushort blueberries = 52130;
        uint strowberries = 4825932;

        Console.WriteLine("In my life I eat  " + apples + " apples " + pearhes + "  pearches " + pears + "  pears " + blueberries + " blueberries " + "  and " +  strowberries + " strowberries ");
        
    }
}

