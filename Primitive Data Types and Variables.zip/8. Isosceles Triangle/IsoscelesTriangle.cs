﻿using System;



    class IsoscelesTriangle
    {
        static void Main()
        {
            //Console.Write("Nakov");
            //Console.Write('\u0008');
            //Console.Write('a');


            char symbol = '\u00A9';
            Console.WriteLine("\t   {0}\n\n\n\t  {0} {0}\n\n\n\t {0}   {0}\n\n\n\t{0} {0} {0} {0}", symbol);
        }
    }


