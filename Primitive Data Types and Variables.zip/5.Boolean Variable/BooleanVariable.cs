﻿using System;


class BooleanVariable
{
    static void Main()
    {
        bool isFemail = false;
        Console.WriteLine(isFemail);
    }
}

