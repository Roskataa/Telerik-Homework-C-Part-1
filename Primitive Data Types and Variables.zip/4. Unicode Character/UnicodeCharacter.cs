﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char symbol = '\u002A';
        Console.WriteLine(symbol);
    }
}

