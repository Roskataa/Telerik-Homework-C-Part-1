﻿using System;


class FloatOrDouble
{
    static void Main()
    {
        double doubleFirstPrecision = 34.567839023;
        Console.WriteLine(doubleFirstPrecision);

        float floatFirstPrecision = 12.345f;
        Console.WriteLine(floatFirstPrecision);

        double doubleSecondPrecision = 8923.1234857;
        Console.WriteLine(doubleSecondPrecision);

        float floatSecondPrecision = 3456.091f;
        Console.WriteLine(floatSecondPrecision);
    }
}

