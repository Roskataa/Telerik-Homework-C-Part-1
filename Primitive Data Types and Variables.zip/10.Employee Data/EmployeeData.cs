﻿using System;

class EmployeeData
{
    static void Main()
    {
        string name = "Rosen";
        string SrName = "Kolev";
        char gender = 'M';
        byte age = 33;
        long personID = 8306112507;
        long employeeNumber = 27560000;
       
        Console.WriteLine("Name :{0} SrName :{1}\n Gender :{2}\n Age :{3}\n PersonID :{4}\n Employee Number :{5}\n", name, SrName, gender, age, personID, employeeNumber);
    }

}


