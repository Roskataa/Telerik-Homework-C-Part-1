﻿using System;

class VariablesInHexadecimalFormat
{
    static void Main()
    {
        int number = 0xFE;
        Console.WriteLine(number);
    }
}

